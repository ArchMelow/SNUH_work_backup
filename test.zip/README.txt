pip install -r requirements.txt 로 필요한 패키지 설치

IDE 에서 xray_gen.py 가 있는 폴더로 이동한 후 
python xray_gen.py 로 프로그램 실행